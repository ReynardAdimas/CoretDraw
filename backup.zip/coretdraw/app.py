import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QColor, QKeySequence
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QColorDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSlider,
    QSpinBox,
    QSplitter,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .canvas import DrawingCanvas


APP_STYLE = """
QMainWindow {
    background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
        stop:0 #25282e,
        stop:1 #1a1c21);
}
QMenuBar {
    background: rgba(30,32,38,0.72);
    color: #f5f7fb;
    border: none;
    padding: 6px 10px;
    font-size: 13px;
}
QMenuBar::item {
    spacing: 8px;
    padding: 6px 10px;
    border-radius: 8px;
    background: transparent;
}
QMenuBar::item:selected {
    background: rgba(255,255,255,0.08);
}
QMenu {
    background: #262a31;
    color: white;
    border: 1px solid rgba(255,255,255,0.08);
}
QFrame#TopBar, QFrame#GlassPanel, QFrame#ToolRail, QFrame#StatusBar {
    background: rgba(40,44,52,0.62);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 16px;
}
QLabel, QCheckBox {
    color: #f4f7fb;
    font-size: 12px;
}
QPushButton, QToolButton {
    background: rgba(255,255,255,0.05);
    color: white;
    border: 1px solid rgba(255,255,255,0.06);
    border-radius: 10px;
    padding: 6px 10px;
    font-weight: 500;
}
QPushButton:hover, QToolButton:hover {
    background: rgba(255,255,255,0.11);
}
QPushButton:checked, QToolButton:checked {
    background: rgba(83,140,255,0.35);
    border: 1px solid rgba(140,180,255,0.45);
}
QToolButton#ToolButton {
    min-width: 40px;
    max-width: 40px;
    min-height: 40px;
    max-height: 40px;
    font-size: 18px;
}
QSlider::groove:horizontal {
    height: 6px;
    background: rgba(255,255,255,0.08);
    border-radius: 3px;
}
QSlider::handle:horizontal {
    width: 16px;
    margin: -5px 0;
    border-radius: 8px;
    background: #76a9ff;
}
QListWidget {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.06);
    border-radius: 12px;
    color: white;
    padding: 6px;
}
QListWidget::item:selected {
    background: rgba(83,140,255,0.45);
    border-radius: 8px;
}
QSpinBox {
    background: rgba(255,255,255,0.05);
    color: white;
    border-radius: 8px;
    border: 1px solid rgba(255,255,255,0.08);
}
QScrollArea {
    border: none;
    background: transparent;
}
"""


class CoretDrawWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CoretDraw X - Liquid Glass Studio")
        self.resize(1600, 960)
        self.canvas = DrawingCanvas()
        self.tool_buttons = {}
        self._build_ui()
        self._build_menus()
        self.canvas.changed.connect(self.refresh_layers)
        self.canvas.statusChanged.connect(self.set_status)
        self.canvas.colorPicked.connect(self._apply_picked_color)
        self.refresh_layers()
        self.set_status("Ready")

    # ---------- UI builders ----------
    def _build_ui(self):
        root = QWidget()
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(10, 8, 10, 10)
        root_layout.setSpacing(8)

        topbar = QFrame(objectName="TopBar")
        top_layout = QHBoxLayout(topbar)
        top_layout.setContentsMargins(12, 6, 12, 6)
        title = QLabel("CoretDraw")
        title.setStyleSheet("font-size: 18px; font-weight: 700; color: #ffffff;")
        top_layout.addWidget(title)
        top_layout.addSpacing(8)
        for label, callback in [
            ("Open", self.open_project), ("Save Project", self.save_project), ("Import", self.import_image),
            ("Export", self.export_image), ("Undo", self.canvas.undo), ("Redo", self.canvas.redo),
        ]:
            top_layout.addWidget(self._button(label, callback))
        top_layout.addStretch()
        self.zoom_label = QLabel("100%")
        top_layout.addWidget(self._button("-", self.canvas.zoom_out))
        top_layout.addWidget(self.zoom_label)
        top_layout.addWidget(self._button("+", self.canvas.zoom_in))
        top_layout.addWidget(self._button("Fit", self.fit_to_view))
        top_layout.addWidget(self._button("Panels", self.toggle_properties))
        root_layout.addWidget(topbar)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)

        self.toolrail = QFrame(objectName="ToolRail")
        tool_layout = QVBoxLayout(self.toolrail)
        tool_layout.setContentsMargins(8, 8, 8, 8)
        tool_layout.setSpacing(6)
        tool_defs = [
            ("pencil", "✎", "Pencil"), ("eraser", "⌫", "Eraser"), ("fill", "▣", "Fill"),
            ("eyedropper", "◉", "Eyedropper"), ("select", "□", "Select/Move"), ("text", "T", "Text"),
            ("line", "╱", "Line"), ("rect", "▭", "Rectangle"), ("roundrect", "▢", "Rounded rectangle"),
            ("ellipse", "◯", "Ellipse"), ("arrow", "➜", "Arrow"), ("star", "★", "Star"),
        ]
        for tool, icon, tip in tool_defs:
            btn = QToolButton(objectName="ToolButton")
            btn.setText(icon)
            btn.setToolTip(tip)
            btn.setCheckable(True)
            btn.clicked.connect(lambda checked=False, t=tool: self.set_tool(t))
            self.tool_buttons[tool] = btn
            tool_layout.addWidget(btn)
        tool_layout.addStretch()
        splitter.addWidget(self.toolrail)

        self.scroll = QScrollArea()
        self.scroll.setWidget(self.canvas)
        self.scroll.setWidgetResizable(False)
        self.scroll.setAlignment(Qt.AlignCenter)
        splitter.addWidget(self.scroll)

        self.properties = QFrame(objectName="GlassPanel")
        props = QVBoxLayout(self.properties)
        props.setContentsMargins(12, 12, 12, 12)
        props.setSpacing(10)
        props.addWidget(self._section_label("Brush & Color"))
        self.stroke_btn = self._button("Stroke #1b1f2a", self.choose_stroke)
        self.fill_btn = self._button("Fill #69a3ff", self.choose_fill)
        props.addWidget(self.stroke_btn)
        props.addWidget(self.fill_btn)
        self.fill_check = QCheckBox("Fill shapes")
        self.fill_check.toggled.connect(self.canvas.set_fill_enabled)
        props.addWidget(self.fill_check)
        self.soft_check = QCheckBox("Soft brush")
        self.soft_check.toggled.connect(self.canvas.set_brush_soft)
        props.addWidget(self.soft_check)
        props.addWidget(QLabel("Brush size"))
        self.brush_slider = QSlider(Qt.Horizontal)
        self.brush_slider.setRange(1, 80)
        self.brush_slider.setValue(4)
        self.brush_slider.valueChanged.connect(self.canvas.set_brush_size)
        props.addWidget(self.brush_slider)
        props.addWidget(QLabel("Opacity"))
        self.opacity_slider = QSlider(Qt.Horizontal)
        self.opacity_slider.setRange(1, 255)
        self.opacity_slider.setValue(255)
        self.opacity_slider.valueChanged.connect(self.canvas.set_brush_opacity)
        props.addWidget(self.opacity_slider)

        props.addWidget(self._section_label("Selection"))
        row = QHBoxLayout()
        row.addWidget(self._button("Crop", self.canvas.crop_to_selection))
        row.addWidget(self._button("Copy Layer", self.canvas.copy_selection_to_new_layer))
        props.addLayout(row)
        props.addWidget(self._button("Clear Selection", self.canvas.clear_selection))

        props.addWidget(self._section_label("Layers"))
        self.layer_list = QListWidget()
        self.layer_list.currentRowChanged.connect(self.layer_selected)
        props.addWidget(self.layer_list, stretch=1)
        layer_row1 = QHBoxLayout()
        layer_row1.addWidget(self._button("+", self.canvas.add_layer))
        layer_row1.addWidget(self._button("Dup", self.canvas.duplicate_active_layer))
        layer_row1.addWidget(self._button("Del", self.canvas.delete_active_layer))
        props.addLayout(layer_row1)
        layer_row2 = QHBoxLayout()
        layer_row2.addWidget(self._button("Up", lambda: self.canvas.move_layer(1)))
        layer_row2.addWidget(self._button("Down", lambda: self.canvas.move_layer(-1)))
        layer_row2.addWidget(self._button("Merge", self.canvas.merge_down))
        props.addLayout(layer_row2)
        self.layer_visible = QCheckBox("Layer visible")
        self.layer_visible.toggled.connect(self.toggle_layer_visible)
        props.addWidget(self.layer_visible)
        props.addWidget(QLabel("Layer opacity"))
        self.layer_opacity = QSlider(Qt.Horizontal)
        self.layer_opacity.setRange(0, 100)
        self.layer_opacity.setValue(100)
        self.layer_opacity.valueChanged.connect(self.change_layer_opacity)
        props.addWidget(self.layer_opacity)
        props.addWidget(self._button("Rename Layer", self.rename_layer))
        props.addWidget(self._button("Flatten", self.canvas.flatten_to_background))

        props.addWidget(self._section_label("Adjust / Filters"))
        for texts in [("Gray", "Invert", "Sepia"), ("Bright+", "Bright-", "Contrast+"), ("Blur", "Sharpen", "Pixel")]:
            row = QHBoxLayout()
            for text in texts:
                row.addWidget(self._filter_button(text))
            props.addLayout(row)
        props.addWidget(self._button("Edge Detect", lambda: self.canvas.apply_filter("edge")))

        props.addWidget(self._section_label("View"))
        self.grid_check = QCheckBox("Show grid")
        self.grid_check.toggled.connect(lambda v: self.canvas.set_grid(show=v))
        self.snap_check = QCheckBox("Snap to grid")
        self.snap_check.toggled.connect(lambda v: self.canvas.set_grid(snap=v))
        props.addWidget(self.grid_check)
        props.addWidget(self.snap_check)
        props.addWidget(self._button("Resize Canvas", self.resize_canvas_dialog))
        props.addStretch()
        splitter.addWidget(self.properties)
        splitter.setSizes([64, 1180, 280])
        root_layout.addWidget(splitter, stretch=1)

        status = QFrame(objectName="StatusBar")
        status_layout = QHBoxLayout(status)
        status_layout.setContentsMargins(14, 7, 14, 7)
        self.status_label = QLabel()
        self.status_label.setStyleSheet("color: #cbd5e1;")
        status_layout.addWidget(self.status_label)
        status_layout.addStretch()
        status_layout.addWidget(QLabel("Tab: panels | Ctrl+S: save project | Ctrl+E: export | Mouse wheel+Ctrl: zoom"))
        root_layout.addWidget(status)
        self.setCentralWidget(root)
        self.set_tool("pencil")

    def _build_menus(self):
        file_menu = self.menuBar().addMenu("File")
        self._add_action(file_menu, "Open Project", self.open_project, "Ctrl+O")
        self._add_action(file_menu, "Save Project", self.save_project, "Ctrl+S")
        self._add_action(file_menu, "Import Image", self.import_image, "Ctrl+I")
        self._add_action(file_menu, "Export Image", self.export_image, "Ctrl+E")
        file_menu.addSeparator()
        self._add_action(file_menu, "Exit", self.close)

        edit_menu = self.menuBar().addMenu("Edit")
        self._add_action(edit_menu, "Undo", self.canvas.undo, "Ctrl+Z")
        self._add_action(edit_menu, "Redo", self.canvas.redo, "Ctrl+Y")
        self._add_action(edit_menu, "Clear Canvas", self.canvas.clear_canvas)
        self._add_action(edit_menu, "Crop to Selection", self.canvas.crop_to_selection)

        layer_menu = self.menuBar().addMenu("Layers")
        self._add_action(layer_menu, "Add Layer", self.canvas.add_layer, "Ctrl+Shift+N")
        self._add_action(layer_menu, "Duplicate Layer", self.canvas.duplicate_active_layer)
        self._add_action(layer_menu, "Delete Layer", self.canvas.delete_active_layer)
        self._add_action(layer_menu, "Merge Down", self.canvas.merge_down)
        self._add_action(layer_menu, "Flatten", self.canvas.flatten_to_background)

        view_menu = self.menuBar().addMenu("View")
        self._add_action(view_menu, "Zoom In", self.canvas.zoom_in, "Ctrl++")
        self._add_action(view_menu, "Zoom Out", self.canvas.zoom_out, "Ctrl+-")
        self._add_action(view_menu, "Reset Zoom", self.canvas.reset_zoom, "Ctrl+0")
        self._add_action(view_menu, "Fit to View", self.fit_to_view)
        self._add_action(view_menu, "Toggle Properties", self.toggle_properties, "Tab")

    def _add_action(self, menu, label, callback, shortcut=None):
        action = QAction(label, self)
        if shortcut:
            action.setShortcut(QKeySequence(shortcut))
        action.triggered.connect(callback)
        menu.addAction(action)
        return action

    def _button(self, text, callback):
        btn = QPushButton(text)
        btn.clicked.connect(lambda checked=False: callback())
        return btn

    def _section_label(self, text):
        label = QLabel(text)
        label.setStyleSheet("font-size: 13px; font-weight: 800; color: #ffffff; margin-top: 7px;")
        return label

    def _filter_button(self, text):
        mapping = {
            "Gray": lambda: self.canvas.apply_adjustment("grayscale"),
            "Invert": lambda: self.canvas.apply_adjustment("invert"),
            "Sepia": lambda: self.canvas.apply_adjustment("sepia"),
            "Bright+": lambda: self.canvas.apply_adjustment("brightness", 24),
            "Bright-": lambda: self.canvas.apply_adjustment("brightness", -24),
            "Contrast+": lambda: self.canvas.apply_adjustment("contrast", 35),
            "Blur": lambda: self.canvas.apply_filter("blur"),
            "Sharpen": lambda: self.canvas.apply_filter("sharpen"),
            "Pixel": lambda: self.canvas.apply_filter("pixelate"),
        }
        return self._button(text, mapping[text])

    # ---------- handlers ----------
    def set_tool(self, tool):
        self.canvas.set_tool(tool)
        for name, button in self.tool_buttons.items():
            button.setChecked(name == tool)

    def set_status(self, text):
        self.status_label.setText(text)
        self.zoom_label.setText(f"{round(self.canvas.zoom * 100)}%")

    def choose_stroke(self):
        color = QColorDialog.getColor(self.canvas.stroke_color, self, "Choose stroke color")
        if color.isValid():
            self.canvas.set_stroke_color(color)
            self.stroke_btn.setText(f"Stroke {color.name()}")

    def choose_fill(self):
        color = QColorDialog.getColor(self.canvas.fill_color, self, "Choose fill color")
        if color.isValid():
            self.canvas.set_fill_color(color)
            self.fill_btn.setText(f"Fill {color.name()}")

    def _apply_picked_color(self, color):
        self.canvas.set_stroke_color(color)
        self.stroke_btn.setText(f"Stroke {color.name()}")

    def import_image(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import image", "", "Images (*.png *.jpg *.jpeg *.bmp *.webp)")
        if path:
            if not self.canvas.import_image(path):
                QMessageBox.warning(self, "Import failed", "Could not import that image.")

    def export_image(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export image", "coretdraw-export.png", "PNG (*.png);;JPEG (*.jpg);;BMP (*.bmp)")
        if path:
            if not self.canvas.export_image(path):
                QMessageBox.warning(self, "Export failed", "Could not export the image.")
            else:
                self.set_status(f"Exported: {path}")

    def save_project(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save CoretDraw project", "untitled.coretdraw", "CoretDraw Project (*.coretdraw)")
        if path:
            self.canvas.save_project(path)

    def open_project(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open CoretDraw project", "", "CoretDraw Project (*.coretdraw)")
        if path:
            try:
                self.canvas.open_project(path)
            except Exception as exc:
                QMessageBox.warning(self, "Open failed", f"Could not open project:\n{exc}")

    def toggle_properties(self):
        self.properties.setVisible(not self.properties.isVisible())

    def fit_to_view(self):
        viewport = self.scroll.viewport().size()
        scale_x = viewport.width() / max(1, self.canvas.canvas_size.width())
        scale_y = viewport.height() / max(1, self.canvas.canvas_size.height())
        self.canvas.set_zoom(min(scale_x, scale_y, 1.0) * 0.96)

    def refresh_layers(self):
        self.layer_list.blockSignals(True)
        self.layer_list.clear()
        for i in range(len(self.canvas.layers) - 1, -1, -1):
            layer = self.canvas.layers[i]
            prefix = "👁 " if layer.visible else "— "
            item = QListWidgetItem(f"{prefix}{layer.name}  {round(layer.opacity * 100)}%")
            item.setData(Qt.UserRole, i)
            self.layer_list.addItem(item)
            if i == self.canvas.active_layer_index:
                self.layer_list.setCurrentItem(item)
        self.layer_list.blockSignals(False)
        layer = self.canvas.active_layer
        self.layer_visible.blockSignals(True)
        self.layer_visible.setChecked(layer.visible)
        self.layer_visible.blockSignals(False)
        self.layer_opacity.blockSignals(True)
        self.layer_opacity.setValue(round(layer.opacity * 100))
        self.layer_opacity.blockSignals(False)
        self.zoom_label.setText(f"{round(self.canvas.zoom * 100)}%")

    def layer_selected(self, row):
        item = self.layer_list.item(row)
        if item is not None:
            index = item.data(Qt.UserRole)
            self.canvas.set_active_layer(index)

    def toggle_layer_visible(self, visible):
        self.canvas.set_layer_visible(self.canvas.active_layer_index, visible)

    def change_layer_opacity(self, value):
        self.canvas.set_layer_opacity(self.canvas.active_layer_index, value)

    def rename_layer(self):
        name, ok = QInputDialog.getText(self, "Rename layer", "Layer name:", text=self.canvas.active_layer.name)
        if ok and name:
            self.canvas.rename_active_layer(name)

    def resize_canvas_dialog(self):
        width, ok = QInputDialog.getInt(self, "Resize Canvas", "Width:", self.canvas.canvas_size.width(), 64, 8000)
        if not ok:
            return
        height, ok = QInputDialog.getInt(self, "Resize Canvas", "Height:", self.canvas.canvas_size.height(), 64, 8000)
        if ok:
            self.canvas.resize_canvas(width, height)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Tab:
            self.toggle_properties()
            event.accept()
            return
        super().keyPressEvent(event)

    def wheelEvent(self, event):
        if event.modifiers() & Qt.ControlModifier:
            if event.angleDelta().y() > 0:
                self.canvas.zoom_in()
            else:
                self.canvas.zoom_out()
            event.accept()
            return
        super().wheelEvent(event)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("CoretDraw")
    app.setStyleSheet(APP_STYLE)
    window = CoretDrawWindow()
    window.show()
    sys.exit(app.exec())
