__app_name__ = "CoretDraw"
__version__ = "0.2.0"
