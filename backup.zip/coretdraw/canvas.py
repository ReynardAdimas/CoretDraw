import json
import math
import os
import tempfile
import zipfile
from dataclasses import dataclass

from PySide6.QtCore import QPoint, QRect, QSize, Qt, Signal
from PySide6.QtGui import (
    QColor,
    QFont,
    QImage,
    QMouseEvent,
    QPainter,
    QPen,
    QPixmap,
    QBrush,
    QPolygon,
)
from PySide6.QtWidgets import QInputDialog, QSizePolicy, QWidget


@dataclass
class Layer:
    name: str
    image: QImage
    visible: bool = True
    opacity: float = 1.0
    locked: bool = False


class DrawingCanvas(QWidget):
    changed = Signal()
    statusChanged = Signal(str)
    colorPicked = Signal(QColor)

    def __init__(self, width=1200, height=800):
        super().__init__()
        self.canvas_size = QSize(width, height)
        self.layers = [Layer("Background", self._new_blank_layer(fill=QColor("white")))]
        self.active_layer_index = 0

        self.tool = "pencil"
        self.stroke_color = QColor("#1b1f2a")
        self.fill_color = QColor("#69a3ff")
        self.fill_enabled = False
        self.brush_size = 4
        self.brush_opacity = 255
        self.brush_soft = False
        self.zoom = 1.0
        self.show_grid = False
        self.snap_to_grid = False
        self.grid_size = 25

        self.is_drawing = False
        self.is_moving_selection = False
        self.last_point = QPoint()
        self.start_point = QPoint()
        self.current_point = QPoint()
        self.selection_rect = QRect()
        self.selection_floating = None
        self.selection_origin = QPoint()

        self.undo_stack = []
        self.redo_stack = []
        self.max_history = 40
        self._push_undo_snapshot()

        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setMinimumSize(self.sizeHint())
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setStyleSheet("background-color: transparent;")

    # ---------- basic state ----------
    def _new_blank_layer(self, fill=None):
        image = QImage(self.canvas_size, QImage.Format_ARGB32_Premultiplied)
        image.fill(QColor(0, 0, 0, 0) if fill is None else fill)
        return image

    @property
    def active_layer(self):
        return self.layers[self.active_layer_index]

    @property
    def active_image(self):
        return self.active_layer.image

    def set_tool(self, tool):
        self.tool = tool
        self.statusChanged.emit(f"Tool: {tool}")

    def set_stroke_color(self, color):
        self.stroke_color = QColor(color)

    def set_fill_color(self, color):
        self.fill_color = QColor(color)

    def set_fill_enabled(self, enabled):
        self.fill_enabled = bool(enabled)

    def set_brush_size(self, size):
        self.brush_size = int(size)

    def set_brush_opacity(self, value):
        self.brush_opacity = max(1, min(255, int(value)))

    def set_brush_soft(self, enabled):
        self.brush_soft = bool(enabled)

    def set_grid(self, show=None, snap=None):
        if show is not None:
            self.show_grid = bool(show)
        if snap is not None:
            self.snap_to_grid = bool(snap)
        self.update()

    def set_zoom(self, zoom):
        self.zoom = max(0.10, min(8.0, float(zoom)))
        self.setMinimumSize(self.sizeHint())
        self.updateGeometry()
        self.update()
        self.statusChanged.emit(f"Zoom: {round(self.zoom * 100)}%")

    def zoom_in(self):
        self.set_zoom(self.zoom * 1.2)

    def zoom_out(self):
        self.set_zoom(self.zoom / 1.2)

    def reset_zoom(self):
        self.set_zoom(1.0)

    def sizeHint(self):
        return QSize(int(self.canvas_size.width() * self.zoom), int(self.canvas_size.height() * self.zoom))

    def _canvas_rect(self):
        scaled_w = int(self.canvas_size.width() * self.zoom)
        scaled_h = int(self.canvas_size.height() * self.zoom)
        x = max(0, (self.width() - scaled_w) // 2)
        y = max(0, (self.height() - scaled_h) // 2)
        return QRect(x, y, scaled_w, scaled_h)

    def _to_image_point(self, widget_pos):
        rect = self._canvas_rect()
        x = int((widget_pos.x() - rect.x()) / self.zoom)
        y = int((widget_pos.y() - rect.y()) / self.zoom)
        x = max(0, min(self.canvas_size.width() - 1, x))
        y = max(0, min(self.canvas_size.height() - 1, y))
        if self.snap_to_grid and self.tool not in {"pencil", "eraser", "fill", "eyedropper"}:
            x = round(x / self.grid_size) * self.grid_size
            y = round(y / self.grid_size) * self.grid_size
            x = max(0, min(self.canvas_size.width() - 1, x))
            y = max(0, min(self.canvas_size.height() - 1, y))
        return QPoint(x, y)

    def _normalized_rect(self, p1=None, p2=None):
        p1 = self.start_point if p1 is None else p1
        p2 = self.current_point if p2 is None else p2
        return QRect(p1, p2).normalized()

    def _make_pen(self, erase=False):
        color = QColor("white") if erase else QColor(self.stroke_color)
        color.setAlpha(self.brush_opacity)
        pen = QPen(color, self.brush_size, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
        return pen

    # ---------- history ----------
    def _snapshot(self):
        return [
            {
                "name": layer.name,
                "image": layer.image.copy(),
                "visible": layer.visible,
                "opacity": layer.opacity,
                "locked": layer.locked,
            }
            for layer in self.layers
        ], self.active_layer_index

    def _restore_snapshot(self, snapshot):
        layer_data, active_index = snapshot
        self.layers = [
            Layer(item["name"], item["image"].copy(), item["visible"], item["opacity"], item["locked"])
            for item in layer_data
        ]
        self.active_layer_index = max(0, min(active_index, len(self.layers) - 1))
        self.selection_rect = QRect()
        self.selection_floating = None
        self.update()
        self.changed.emit()

    def _push_undo_snapshot(self):
        self.undo_stack.append(self._snapshot())
        if len(self.undo_stack) > self.max_history:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def undo(self):
        if len(self.undo_stack) <= 1:
            return
        self.redo_stack.append(self.undo_stack.pop())
        self._restore_snapshot(self.undo_stack[-1])
        self.statusChanged.emit("Undo")

    def redo(self):
        if not self.redo_stack:
            return
        snapshot = self.redo_stack.pop()
        self.undo_stack.append(snapshot)
        self._restore_snapshot(snapshot)
        self.statusChanged.emit("Redo")

    def _commit_change(self, message="Updated"):
        self._push_undo_snapshot()
        self.update()
        self.changed.emit()
        self.statusChanged.emit(message)

    # ---------- layers ----------
    def add_layer(self, name=None):
        name = name or f"Layer {len(self.layers)}"
        self.layers.append(Layer(name, self._new_blank_layer()))
        self.active_layer_index = len(self.layers) - 1
        self._commit_change(f"Added {name}")

    def duplicate_active_layer(self):
        src = self.active_layer
        self.layers.insert(self.active_layer_index + 1, Layer(src.name + " copy", src.image.copy(), src.visible, src.opacity, src.locked))
        self.active_layer_index += 1
        self._commit_change("Layer duplicated")

    def delete_active_layer(self):
        if len(self.layers) <= 1:
            self.statusChanged.emit("At least one layer is required")
            return
        self.layers.pop(self.active_layer_index)
        self.active_layer_index = max(0, self.active_layer_index - 1)
        self._commit_change("Layer deleted")

    def merge_down(self):
        if self.active_layer_index <= 0:
            return
        top = self.active_layer
        below = self.layers[self.active_layer_index - 1]
        painter = QPainter(below.image)
        painter.setOpacity(top.opacity if top.visible else 0)
        painter.drawImage(0, 0, top.image)
        painter.end()
        self.layers.pop(self.active_layer_index)
        self.active_layer_index -= 1
        self._commit_change("Merged layer down")

    def move_layer(self, direction):
        new_index = self.active_layer_index + direction
        if 0 <= new_index < len(self.layers):
            self.layers[self.active_layer_index], self.layers[new_index] = self.layers[new_index], self.layers[self.active_layer_index]
            self.active_layer_index = new_index
            self._commit_change("Layer reordered")

    def set_active_layer(self, index):
        if 0 <= index < len(self.layers):
            self.active_layer_index = index
            self.changed.emit()
            self.update()

    def set_layer_visible(self, index, visible):
        if 0 <= index < len(self.layers):
            self.layers[index].visible = bool(visible)
            self._commit_change("Layer visibility changed")

    def set_layer_opacity(self, index, value):
        if 0 <= index < len(self.layers):
            self.layers[index].opacity = max(0.0, min(1.0, value / 100.0))
            self._commit_change("Layer opacity changed")

    def rename_active_layer(self, name):
        if name:
            self.active_layer.name = name
            self._commit_change("Layer renamed")

    # ---------- composition ----------
    def composite_image(self):
        result = QImage(self.canvas_size, QImage.Format_ARGB32_Premultiplied)
        result.fill(QColor(255, 255, 255, 0))
        painter = QPainter(result)
        for layer in self.layers:
            if layer.visible:
                painter.setOpacity(layer.opacity)
                painter.drawImage(0, 0, layer.image)
        painter.end()
        return result

    def flatten_to_background(self):
        flat = self.composite_image()
        self.layers = [Layer("Background", flat)]
        self.active_layer_index = 0
        self._commit_change("Flattened image")

    # ---------- paint events ----------
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = self._canvas_rect()

        painter.fillRect(rect.adjusted(-18, -18, 18, 18), QColor(0, 0, 0, 38))
        painter.fillRect(rect, QColor("white"))

        composite = self.composite_image()
        if self.selection_floating is not None:
            temp = composite.copy()
            tp = QPainter(temp)
            tp.drawImage(self.selection_rect.topLeft(), self.selection_floating)
            tp.end()
            composite = temp
        painter.drawPixmap(rect, QPixmap.fromImage(composite))

        if self.is_drawing and self.tool in {"line", "rect", "roundrect", "ellipse", "arrow", "star"}:
            self._draw_preview_shape(painter, rect)

        if self.show_grid:
            self._draw_grid(painter, rect)
        if not self.selection_rect.isNull():
            self._draw_selection_overlay(painter, rect)

        painter.setPen(QPen(QColor(255, 255, 255, 85), 2))
        painter.drawRoundedRect(rect, 8, 8)

    def _draw_grid(self, painter, canvas_rect):
        painter.save()
        painter.setPen(QPen(QColor(0, 0, 0, 35), 1))
        step = max(2, int(self.grid_size * self.zoom))
        for x in range(canvas_rect.left(), canvas_rect.right(), step):
            painter.drawLine(x, canvas_rect.top(), x, canvas_rect.bottom())
        for y in range(canvas_rect.top(), canvas_rect.bottom(), step):
            painter.drawLine(canvas_rect.left(), y, canvas_rect.right(), y)
        painter.restore()

    def _scaled_rect(self, image_rect, canvas_rect):
        return QRect(
            canvas_rect.x() + int(image_rect.x() * self.zoom),
            canvas_rect.y() + int(image_rect.y() * self.zoom),
            int(image_rect.width() * self.zoom),
            int(image_rect.height() * self.zoom),
        )

    def _draw_selection_overlay(self, painter, canvas_rect):
        painter.save()
        pen = QPen(QColor("#2f8cff"), 2, Qt.DashLine)
        painter.setPen(pen)
        painter.setBrush(QColor(47, 140, 255, 28))
        painter.drawRect(self._scaled_rect(self.selection_rect, canvas_rect))
        painter.restore()

    def _draw_preview_shape(self, painter, canvas_rect):
        preview = QImage(self.canvas_size, QImage.Format_ARGB32_Premultiplied)
        preview.fill(QColor(0, 0, 0, 0))
        p = QPainter(preview)
        p.setRenderHint(QPainter.Antialiasing)
        self._draw_shape_on_painter(p, self.start_point, self.current_point)
        p.end()
        painter.drawPixmap(canvas_rect, QPixmap.fromImage(preview))

    def _draw_shape_on_painter(self, painter, p1, p2):
        painter.setPen(self._make_pen())
        painter.setBrush(QBrush(self.fill_color if self.fill_enabled else Qt.NoBrush))
        rect = QRect(p1, p2).normalized()
        if self.tool == "line":
            painter.drawLine(p1, p2)
        elif self.tool == "rect":
            painter.drawRect(rect)
        elif self.tool == "roundrect":
            painter.drawRoundedRect(rect, 20, 20)
        elif self.tool == "ellipse":
            painter.drawEllipse(rect)
        elif self.tool == "arrow":
            painter.drawLine(p1, p2)
            self._draw_arrow_head(painter, p1, p2)
        elif self.tool == "star":
            painter.drawPolygon(self._star_polygon(rect))

    def _draw_arrow_head(self, painter, p1, p2):
        angle = math.atan2(p2.y() - p1.y(), p2.x() - p1.x())
        length = max(12, self.brush_size * 4)
        a1 = angle + math.pi * 0.82
        a2 = angle - math.pi * 0.82
        left = QPoint(int(p2.x() + math.cos(a1) * length), int(p2.y() + math.sin(a1) * length))
        right = QPoint(int(p2.x() + math.cos(a2) * length), int(p2.y() + math.sin(a2) * length))
        painter.drawLine(p2, left)
        painter.drawLine(p2, right)

    def _star_polygon(self, rect):
        cx = rect.center().x()
        cy = rect.center().y()
        outer = max(2, min(rect.width(), rect.height()) / 2)
        inner = outer * 0.45
        points = []
        for i in range(10):
            radius = outer if i % 2 == 0 else inner
            angle = -math.pi / 2 + i * math.pi / 5
            points.append(QPoint(int(cx + math.cos(angle) * radius), int(cy + math.sin(angle) * radius)))
        return QPolygon(points)

    # ---------- mouse tools ----------
    def mousePressEvent(self, event: QMouseEvent):
        if event.button() != Qt.LeftButton:
            return
        self.setFocus()
        point = self._to_image_point(event.position().toPoint())
        self.start_point = point
        self.current_point = point
        self.last_point = point

        if self.tool == "eyedropper":
            color = QColor(self.composite_image().pixel(point))
            self.colorPicked.emit(color)
            self.statusChanged.emit(f"Picked color {color.name()}")
            return
        if self.tool == "fill":
            self._flood_fill(point, self.fill_color)
            self._commit_change("Area filled")
            return
        if self.tool == "text":
            self._place_text(point)
            return
        if self.tool == "select" and self.selection_rect.contains(point) and not self.selection_rect.isNull():
            self._begin_move_selection(point)
            return

        self.is_drawing = True

    def mouseMoveEvent(self, event: QMouseEvent):
        point = self._to_image_point(event.position().toPoint())
        self.current_point = point
        if self.is_moving_selection:
            delta = point - self.selection_origin
            self.selection_rect.moveTo(self.selection_rect.topLeft() + delta)
            self.selection_origin = point
            self.update()
            return
        if not self.is_drawing:
            return
        if self.tool in {"pencil", "eraser"}:
            self._draw_freehand(self.last_point, point, erase=(self.tool == "eraser"))
            self.last_point = point
            self.update()
        elif self.tool == "select":
            self.selection_rect = self._normalized_rect(self.start_point, point)
            self.update()
        else:
            self.update()

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() != Qt.LeftButton:
            return
        point = self._to_image_point(event.position().toPoint())
        self.current_point = point
        if self.is_moving_selection:
            self._end_move_selection()
            return
        if not self.is_drawing:
            return
        self.is_drawing = False
        if self.active_layer.locked:
            self.statusChanged.emit("Active layer is locked")
            return
        if self.tool in {"line", "rect", "roundrect", "ellipse", "arrow", "star"}:
            painter = QPainter(self.active_image)
            painter.setRenderHint(QPainter.Antialiasing)
            self._draw_shape_on_painter(painter, self.start_point, point)
            painter.end()
            self._commit_change("Shape drawn")
        elif self.tool in {"pencil", "eraser"}:
            self._commit_change("Stroke drawn")
        elif self.tool == "select":
            self.selection_rect = self._normalized_rect(self.start_point, point)
            self.update()
            self.statusChanged.emit("Selection created")

    def _draw_freehand(self, p1, p2, erase=False):
        if self.active_layer.locked:
            return
        painter = QPainter(self.active_image)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(self._make_pen(erase=erase))
        if self.brush_soft and not erase:
            color = QColor(self.stroke_color)
            color.setAlpha(max(18, self.brush_opacity // 4))
            painter.setPen(QPen(color, self.brush_size * 2, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
            painter.drawLine(p1, p2)
            painter.setPen(self._make_pen())
        painter.drawLine(p1, p2)
        painter.end()

    def _place_text(self, point):
        if self.active_layer.locked:
            return
        text, ok = QInputDialog.getText(self, "Add Text", "Text:")
        if not ok or not text:
            return
        size, ok = QInputDialog.getInt(self, "Font Size", "Size:", 42, 8, 240)
        if not ok:
            return
        painter = QPainter(self.active_image)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(QPen(self.stroke_color, 1))
        painter.setFont(QFont("Segoe UI", size))
        painter.drawText(point, text)
        painter.end()
        self._commit_change("Text added")

    def _begin_move_selection(self, point):
        if self.active_layer.locked:
            return
        self.selection_rect = self.selection_rect.intersected(QRect(QPoint(0, 0), self.canvas_size))
        if self.selection_rect.isNull():
            return
        self.selection_floating = self.active_image.copy(self.selection_rect)
        painter = QPainter(self.active_image)
        painter.setCompositionMode(QPainter.CompositionMode_Clear)
        painter.fillRect(self.selection_rect, Qt.transparent)
        painter.end()
        self.selection_origin = point
        self.is_moving_selection = True

    def _end_move_selection(self):
        if self.selection_floating is not None:
            painter = QPainter(self.active_image)
            painter.drawImage(self.selection_rect.topLeft(), self.selection_floating)
            painter.end()
            self.selection_floating = None
            self.is_moving_selection = False
            self._commit_change("Selection moved")

    def crop_to_selection(self):
        if self.selection_rect.isNull():
            self.statusChanged.emit("No selection to crop")
            return
        rect = self.selection_rect.intersected(QRect(QPoint(0, 0), self.canvas_size))
        if rect.isNull():
            return
        for layer in self.layers:
            layer.image = layer.image.copy(rect)
        self.canvas_size = rect.size()
        self.selection_rect = QRect()
        self._commit_change("Cropped to selection")
        self.setMinimumSize(self.sizeHint())

    def clear_selection(self):
        self.selection_rect = QRect()
        self.selection_floating = None
        self.update()

    def copy_selection_to_new_layer(self):
        if self.selection_rect.isNull():
            return
        new_img = self._new_blank_layer()
        painter = QPainter(new_img)
        painter.drawImage(self.selection_rect.topLeft(), self.active_image.copy(self.selection_rect))
        painter.end()
        self.layers.append(Layer("Selection copy", new_img))
        self.active_layer_index = len(self.layers) - 1
        self._commit_change("Selection copied to new layer")

    # ---------- fill and image operations ----------
    def _flood_fill(self, start, color):
        if self.active_layer.locked:
            return
        img = self.active_image
        w, h = img.width(), img.height()
        target = img.pixelColor(start)
        replacement = QColor(color)
        if target == replacement:
            return
        stack = [(start.x(), start.y())]
        while stack:
            x, y = stack.pop()
            if x < 0 or x >= w or y < 0 or y >= h:
                continue
            if img.pixelColor(x, y) != target:
                continue
            img.setPixelColor(x, y, replacement)
            stack.extend(((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)))

    def import_image(self, path):
        loaded = QImage(path)
        if loaded.isNull():
            return False
        target = self._new_blank_layer()
        scaled = loaded.scaled(self.canvas_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        x = (self.canvas_size.width() - scaled.width()) // 2
        y = (self.canvas_size.height() - scaled.height()) // 2
        painter = QPainter(target)
        painter.drawImage(x, y, scaled.convertToFormat(QImage.Format_ARGB32_Premultiplied))
        painter.end()
        self.layers.append(Layer(os.path.basename(path), target))
        self.active_layer_index = len(self.layers) - 1
        self._commit_change("Image imported as layer")
        return True

    def export_image(self, path):
        return self.composite_image().save(path)

    def clear_canvas(self):
        for i, layer in enumerate(self.layers):
            layer.image.fill(QColor("white") if i == 0 else QColor(0, 0, 0, 0))
        self.selection_rect = QRect()
        self._commit_change("Canvas cleared")

    def resize_canvas(self, width, height):
        width, height = int(width), int(height)
        if width <= 0 or height <= 0:
            return
        new_size = QSize(width, height)
        for layer in self.layers:
            new_img = QImage(new_size, QImage.Format_ARGB32_Premultiplied)
            new_img.fill(QColor(0, 0, 0, 0))
            painter = QPainter(new_img)
            painter.drawImage(0, 0, layer.image)
            painter.end()
            layer.image = new_img
        self.canvas_size = new_size
        self.selection_rect = QRect()
        self._commit_change("Canvas resized")
        self.setMinimumSize(self.sizeHint())

    def apply_adjustment(self, mode, amount=0):
        img = self.active_image
        for y in range(img.height()):
            for x in range(img.width()):
                c = img.pixelColor(x, y)
                if c.alpha() == 0:
                    continue
                r, g, b, a = c.red(), c.green(), c.blue(), c.alpha()
                if mode == "grayscale":
                    v = int(0.299 * r + 0.587 * g + 0.114 * b)
                    r = g = b = v
                elif mode == "invert":
                    r, g, b = 255 - r, 255 - g, 255 - b
                elif mode == "sepia":
                    nr = min(255, int(r * 0.393 + g * 0.769 + b * 0.189))
                    ng = min(255, int(r * 0.349 + g * 0.686 + b * 0.168))
                    nb = min(255, int(r * 0.272 + g * 0.534 + b * 0.131))
                    r, g, b = nr, ng, nb
                elif mode == "brightness":
                    r = max(0, min(255, r + amount)); g = max(0, min(255, g + amount)); b = max(0, min(255, b + amount))
                elif mode == "contrast":
                    factor = (259 * (amount + 255)) / (255 * (259 - amount))
                    r = max(0, min(255, int(factor * (r - 128) + 128)))
                    g = max(0, min(255, int(factor * (g - 128) + 128)))
                    b = max(0, min(255, int(factor * (b - 128) + 128)))
                img.setPixelColor(x, y, QColor(r, g, b, a))
        self._commit_change(f"Applied {mode}")

    def apply_filter(self, mode):
        if mode == "pixelate":
            block = 10
            img = self.active_image
            for y in range(0, img.height(), block):
                for x in range(0, img.width(), block):
                    c = img.pixelColor(x, y)
                    for yy in range(y, min(y + block, img.height())):
                        for xx in range(x, min(x + block, img.width())):
                            if img.pixelColor(xx, yy).alpha() > 0:
                                img.setPixelColor(xx, yy, c)
            self._commit_change("Pixelate filter")
            return

        kernel = None
        divisor = 1
        if mode == "blur":
            kernel = [[1, 1, 1], [1, 1, 1], [1, 1, 1]]
            divisor = 9
        elif mode == "sharpen":
            kernel = [[0, -1, 0], [-1, 5, -1], [0, -1, 0]]
            divisor = 1
        elif mode == "edge":
            kernel = [[-1, -1, -1], [-1, 8, -1], [-1, -1, -1]]
            divisor = 1
        if kernel is None:
            return
        src = self.active_image.copy()
        dst = self.active_image
        for y in range(1, src.height() - 1):
            for x in range(1, src.width() - 1):
                alpha = src.pixelColor(x, y).alpha()
                if alpha == 0:
                    continue
                r = g = b = 0
                for ky in range(3):
                    for kx in range(3):
                        c = src.pixelColor(x + kx - 1, y + ky - 1)
                        weight = kernel[ky][kx]
                        r += c.red() * weight
                        g += c.green() * weight
                        b += c.blue() * weight
                r = max(0, min(255, int(r / divisor)))
                g = max(0, min(255, int(g / divisor)))
                b = max(0, min(255, int(b / divisor)))
                dst.setPixelColor(x, y, QColor(r, g, b, alpha))
        self._commit_change(f"Applied {mode}")

    # ---------- project format ----------
    def save_project(self, path):
        if not path.endswith(".coretdraw"):
            path += ".coretdraw"
        manifest = {
            "app": "CoretDraw",
            "version": "0.2.0",
            "width": self.canvas_size.width(),
            "height": self.canvas_size.height(),
            "active_layer": self.active_layer_index,
            "layers": [
                {"name": l.name, "visible": l.visible, "opacity": l.opacity, "locked": l.locked, "file": f"layers/{i}.png"}
                for i, l in enumerate(self.layers)
            ],
        }
        with tempfile.TemporaryDirectory() as tmp:
            os.makedirs(os.path.join(tmp, "layers"), exist_ok=True)
            with open(os.path.join(tmp, "manifest.json"), "w", encoding="utf-8") as f:
                json.dump(manifest, f, indent=2)
            for i, layer in enumerate(self.layers):
                layer.image.save(os.path.join(tmp, "layers", f"{i}.png"))
            with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
                zf.write(os.path.join(tmp, "manifest.json"), "manifest.json")
                for i in range(len(self.layers)):
                    zf.write(os.path.join(tmp, "layers", f"{i}.png"), f"layers/{i}.png")
        self.statusChanged.emit(f"Project saved: {os.path.basename(path)}")
        return True

    def open_project(self, path):
        with tempfile.TemporaryDirectory() as tmp:
            with zipfile.ZipFile(path, "r") as zf:
                zf.extractall(tmp)
            with open(os.path.join(tmp, "manifest.json"), "r", encoding="utf-8") as f:
                manifest = json.load(f)
            self.canvas_size = QSize(int(manifest["width"]), int(manifest["height"]))
            loaded_layers = []
            for item in manifest["layers"]:
                img = QImage(os.path.join(tmp, item["file"])).convertToFormat(QImage.Format_ARGB32_Premultiplied)
                loaded_layers.append(Layer(item["name"], img, item.get("visible", True), item.get("opacity", 1.0), item.get("locked", False)))
            self.layers = loaded_layers or [Layer("Background", self._new_blank_layer(fill=QColor("white")))]
            self.active_layer_index = max(0, min(int(manifest.get("active_layer", 0)), len(self.layers) - 1))
            self.undo_stack.clear(); self.redo_stack.clear(); self._push_undo_snapshot()
            self.selection_rect = QRect()
            self.setMinimumSize(self.sizeHint())
            self.changed.emit(); self.update()
            self.statusChanged.emit(f"Project opened: {os.path.basename(path)}")
        return True
