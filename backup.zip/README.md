# CoretDraw 0.2

CoretDraw adalah aplikasi drawing/editor gambar desktop ringan berbasis **Python + PySide6** dengan tampilan **liquid glass / glassmorphism**.

Versi ini adalah pengembangan dari compact UI awal, dengan fokus pada workspace yang lega dan fitur editing yang lebih luas.

## Fitur utama

### Drawing tools

- Pencil/freehand drawing
- Eraser
- Fill bucket
- Eyedropper/color picker dari canvas
- Text tool
- Line
- Rectangle
- Rounded rectangle
- Ellipse/circle
- Arrow
- Star

### Brush & color

- Stroke color
- Fill color
- Toggle fill shape
- Brush size
- Brush opacity
- Soft brush mode

### Canvas view

- Zoom in/out
- Fit to view
- Reset zoom
- Pan dengan scrollbar area canvas
- Show grid
- Snap to grid
- Resize canvas

### Selection

- Rectangle selection
- Move selected area dengan drag ulang pada selection
- Crop to selection
- Copy selection to new layer
- Clear selection

### Layers

- Add layer
- Delete layer
- Duplicate layer
- Rename layer
- Reorder layer up/down
- Hide/show layer
- Layer opacity
- Merge down
- Flatten image
- Import image sebagai layer baru

### Image adjustment & filters

- Grayscale
- Invert
- Sepia
- Brightness + / -
- Contrast +
- Blur
- Sharpen
- Pixelate
- Edge detect

### File support

- Import image: PNG, JPG, JPEG, BMP, WEBP
- Export final image: PNG, JPG, BMP
- Save project: `.coretdraw`
- Open project: `.coretdraw`

Format `.coretdraw` menyimpan canvas, layer, visibility, opacity, dan metadata project dalam satu file project.

## Cara menjalankan

```bash
cd coretdraw
pip install -r requirements.txt
python main.py
```

## Shortcut

- `Ctrl+O`: open project
- `Ctrl+S`: save project
- `Ctrl+I`: import image
- `Ctrl+E`: export image
- `Ctrl+Z`: undo
- `Ctrl+Y`: redo
- `Ctrl++`: zoom in
- `Ctrl+-`: zoom out
- `Ctrl+0`: reset zoom
- `Tab`: hide/show properties panel
- `Ctrl + mouse wheel`: zoom

## Cara memakai selection move

1. Pilih tool **Select**.
2. Drag untuk membuat selection.
3. Klik dan drag lagi di dalam area selection untuk memindahkan pixel pada active layer.
4. Lepas mouse untuk commit perubahan.

## Build ke `.exe`

```bash
pip install pyinstaller
pyinstaller --onefile --windowed main.py
```

Hasil build ada di folder `dist/`.

## Catatan versi

Fitur-fitur besar seperti layer, selection, filter, dan project format sudah tersedia sebagai implementasi awal yang ringan. Untuk versi berikutnya, fitur yang bisa ditingkatkan adalah blend mode layer, lasso selection, editable text layer, non-destructive adjustment layer, dan brush engine yang lebih advanced.
